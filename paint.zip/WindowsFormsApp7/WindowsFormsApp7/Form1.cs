﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        Graphics g; //Για γραμμική επιφάνεια σχεδίασης
        Pen p;
        Pen p2;
        RectangleF rect;
        RectangleF rec0;
        RectangleF rec1;
        RectangleF rec2;
        int counter;int counter1;
        int x1;
        int y1;
        bool freestyle; bool freestyle2;
        bool startshape; bool startshape2;
        bool startelipse; bool startelipse2;
        bool startline; bool startline2;
        bool erasestyle; bool erasestyle2;
        int fsx1, fsy1;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            g = this.CreateGraphics();  //To g συνδέεται με μια επιφάνεια σχεδίασης CreateGraphics της φόρμας
            p = new Pen(Color.Blue, 1);  //Μέσα δέχεται ένα brush με πάχος του στυλού και χρωμα
            p2 = new Pen(Color.White, 1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            startline = true;
            freestyle = false;
            startshape = false;
            startelipse = false;
            erasestyle = false;
            connSender("line", DateTime.Now.ToString());
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (startline)
            {
                x1 = e.X;
                y1 = e.Y;
                startline2 = true;
            }
            if (freestyle)
            {
                fsx1 = e.X;
                fsy1 = e.Y;
                freestyle2 = true;
            }
            if (startshape)
            {
                fsx1 = e.X;
                fsy1 = e.Y;
                startshape2 = true;
            }
            if (startelipse)
            {
                fsx1 = e.X;
                fsy1 = e.Y;
                startelipse2 = true;
            }
            if (erasestyle)
            {
                fsx1 = e.X;
                fsy1 = e.Y;
                erasestyle2 = true;
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (startline2)
            {
                g.DrawLine(p, x1, y1, e.X, e.Y);
            }
            startline2 = false;

            freestyle2 = false;

            if (startshape2)
            {
                g.DrawRectangle(p, fsx1, fsy1, e.X - fsx1, e.Y - fsy1);
            }
            startshape2 = false;

            if (startelipse2)
            {
                g.DrawEllipse(p, fsx1, fsy1, e.X - fsx1, e.Y - fsy1);
            }
            startelipse2 = false;
            erasestyle2 = false;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            label2.Text = e.X.ToString();
            label3.Text = e.Y.ToString();
            if (freestyle2)
            {
                g.DrawLine(p, fsx1, fsy1, e.X, e.Y);
                fsx1 = e.X; //κανουμε update τις νέες συνταταγμενες που προκυπτουν ενω σχεδιάζουμε
                fsy1 = e.Y;
            }
            if (startshape2)
            {




            }
            if (erasestyle2)
            {
                g.DrawLine(p2, fsx1, fsy1, e.X, e.Y);
                fsx1 = e.X;
                fsy1 = e.Y;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //g.DrawRectangle(p, 150, 160, 200, 85);
            freestyle = false;
            startelipse = false;
            startline = false;
            erasestyle = false;
            startshape = true;
            connSender("rectangle", DateTime.Now.ToString());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //g.DrawEllipse(p, 150, 160, 200, 85);
            freestyle = false;
            startshape = false;
            startline = false;
            erasestyle = false;
            startelipse = true;
            connSender("ellipse", DateTime.Now.ToString());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            freestyle = true;
            startshape = false;
            startelipse = false;
            startline = false;
            erasestyle = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            counter++;
            rect = new RectangleF(685, 255, 30, 12);
            if (counter == 1)
            {
                g.DrawArc(p, rect, 0, 180); 
            }
            else if (counter == 2)
            {
                g.DrawLine(p, 685, 262, 685, 230);
            }
            else if (counter == 3)
            {
                g.DrawLine(p, 715, 262, 715, 230);
            }
            else if (counter == 4)
            {
                g.DrawLine(p, 600, 230, 800, 230);
            }
            else if (counter == 5)
            {
                g.DrawLine(p, 600, 230, 650, 180);
            }
            else if (counter == 6)
            {
                g.DrawLine(p, 800, 230, 750, 180);
            }
            else if (counter == 7)
            {
                g.DrawLine(p, 650, 180, 625, 180);
            }
            else if (counter == 8)
            {
                g.DrawLine(p, 750, 180, 775, 180);
            }
            else if (counter == 9)
            {
                g.DrawLine(p, 625, 180, 675, 130);
            }
            else if (counter == 10)
            {
                g.DrawLine(p, 775, 180, 725, 130);
            }
            else if (counter == 11)
            {
                g.DrawLine(p, 675, 130, 650, 130);
            }
            else if (counter == 12)
            {
                g.DrawLine(p, 725, 130, 750, 130);
            }
            else if (counter == 13)
            {
                g.DrawLine(p, 650, 130, 700, 80);
            }
            else if (counter == 14)
            {
                g.DrawLine(p, 750, 130, 700, 80);
            }
            else if (counter == 15)
            {
                g.DrawLine(p, 700, 80, 720, 90);
            }
            else if (counter == 16)
            {
                g.DrawLine(p, 700, 80, 680, 90);
            }
            else if (counter == 17)
            {
                g.DrawLine(p, 720, 90, 710, 70);
            }
            else if (counter == 18)
            {
                g.DrawLine(p, 680, 90, 690, 70);
            }
            else if (counter == 19)
            {
                g.DrawLine(p, 710, 70, 730, 60);
            }
            else if (counter == 20)
            {
                g.DrawLine(p, 690, 70, 670, 60);
            }
            else if (counter == 21)
            {
                g.DrawLine(p, 690, 60, 700, 40);
            }
            else if (counter == 22)
            {
                g.DrawLine(p, 730, 60, 710, 60);
            }
            else if (counter == 23)
            {
                g.DrawLine(p, 670, 60, 690, 60);
            }
            else
            {
                g.DrawLine(p, 710, 60, 700, 40);
                counter = 0;
                timer1.Enabled = false;
            }
        }

        
        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            startline = false;
            freestyle = false;
            startshape = false;
            startelipse = false;
            erasestyle = true;
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            p.Width = trackBar1.Value;
            p2.Width = trackBar1.Value;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
                p.Color = colorDialog1.Color;
        }

        private void greenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            changeColor(sender, Color.Green);
        }

        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            changeColor(sender, Color.Blue);
        }

        private void redToolStripMenuItem_Click(object sender, EventArgs e)
        {
            changeColor(sender, Color.Red);
        }

        private void yellowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            changeColor(sender, Color.Yellow);
        }

        private void orangeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            changeColor(sender, Color.Orange);
        }

        private void changeColor(object sender, Color color)
        {
            ToolStripItem item = (ToolStripItem)sender;
            ContextMenuStrip owner = (ContextMenuStrip)item.Owner;
            Control usedControl = owner.SourceControl;
            if (usedControl.GetType() == typeof(Button))
            {
                Button b = (Button)usedControl;
                b.BackColor = color;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            timer2.Enabled = true;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            counter1++;
            rec0 = new RectangleF(250, 350, 100, 150);
            rec1 = new RectangleF(260, 370, 80, 120);
            rec2 = new RectangleF(270, 390, 60, 90);
            if (counter1 == 1)
            {
                g.DrawArc(p, rec0, 245, 50);
            }
            else if(counter1 == 2)
            {
                g.DrawArc(p, rec1, 250, 40);
            }
            else if(counter1 == 3)
            {
                g.DrawArc(p, rec2, 255, 30);
            }
            else if(counter1 == 4)
            {
                g.DrawEllipse(p, 295, 402, 9, 9);
                counter1 = 0;
                timer2.Enabled = false;
            }
        }

        private void connSender(String type, String time)
        {
            String connectionString = "Data Source=DB10.db;Version = 3;";
            SQLiteConnection conn = new SQLiteConnection(connectionString);
            conn.Open();
            String insertQuery = "Insert into Sxima(Type,Time) values(@type,@time)";
            SQLiteCommand cmd = new SQLiteCommand(insertQuery, conn);
            cmd.Parameters.AddWithValue("@type", type);
            cmd.Parameters.AddWithValue("@time", time);
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }
}
